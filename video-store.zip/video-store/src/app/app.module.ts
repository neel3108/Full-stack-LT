import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule, MatCardModule, MatButtonModule, MatToolbarModule, MatSelectModule } from '@angular/material';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddVideoComponent } from './videos/add-video/add-video.component';
import {CustomerVideoList} from './videos/customers-video-list/customers-video-list.component';
import { VideoListComponent } from './videos/video-list/video-list.component';
import { VideoService } from './videos/videos.service';
import { UpdateVideoComponent } from '../app/videos/update-video/update-video.component';
import { AdminLoginComponent } from '../app/videos/admin/admin-login/admin-login.component';

const routes: Routes = [];

@NgModule({
  declarations: [
    AppComponent,
    AddVideoComponent,
    VideoListComponent,
    UpdateVideoComponent,
    CustomerVideoList,
    AdminLoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
    MatToolbarModule,
    MatSelectModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  providers: [VideoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
