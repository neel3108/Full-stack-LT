import { Component } from "@angular/core";
import { Router } from '@angular/router';
import { routerNgProbeToken } from "@angular/router/src/router_module";

@Component({
  selector:'admin-login',
  templateUrl: './admin-login.component.html'
})
export class AdminLoginComponent {

  constructor(public router: Router){}

  onLogin(){
    this.router.navigateByUrl('/videoList');
  }
}
