import { Component, OnInit } from "@angular/core";
import { VideoService } from "../videos.service";
import { Video } from '../video.model';

@Component({
  selector: 'customer-video-list',
  templateUrl: './customers-video-list.component.html'
})
export class CustomerVideoList implements OnInit{
  videos: Video[];
  public searchInput = "";

  constructor(public videoService: VideoService){}

  ngOnInit(){
    this.showCustomerVideoList();
  }

  showCustomerVideoList(){
    this.videoService.getVideoList().subscribe((res) => {
      this.videoService.videos = res as Video[];
    })
  }

  get getSearch(){
    if(this.searchInput.length > 0){
      return this.videos.filter(video => video.vidTitle.toLowerCase().includes(this.searchInput.toLowerCase()));
    }
    return this.videos;
  }
}
