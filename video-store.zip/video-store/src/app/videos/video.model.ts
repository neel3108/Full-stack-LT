export interface Video {
  _id: String;
  vidTitle : String,
  runningTime : String,
  director : String,
  genre: String,
  rating: String,
  status: string
}

