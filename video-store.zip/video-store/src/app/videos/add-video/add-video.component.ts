import { Component, OnInit } from "@angular/core";


import { NgForm } from "@angular/forms";
import { VideoService } from "../videos.service";


@Component({
  selector: 'app-add-video',
  templateUrl : './add-video.component.html',
  styleUrls: ['./add-video.component.css']
})
export class AddVideoComponent {

  constructor(public videoService: VideoService){}

  ngOnInit(){
  }

  addVideo(form: NgForm){
    if(form.invalid){ return; }
    else {
      this.videoService.addVideotoDB(form.value).subscribe((res) => {
            alert('Video Added');
            form.resetForm();

          });
        }
  }
}

