import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import {throwError as observableThrowError, Observable} from  'rxjs';
import {catchError} from 'rxjs/operators';

import { Video } from './video.model';

@Injectable({providedIn: 'root'})
export class VideoService {
  videos: Video[] = [];
  selectedVideo: Video;
  readonly baseURL = "http://localhost:4100/videos/";


  constructor(public http : HttpClient){}

  getVideoList(){
    return this.http.get(this.baseURL);
  }

  getSelectedVideo( _id: String){
    return this.http.get(this.baseURL + _id);
  }

  addVideotoDB(vid : Video){
    return this.http.post(this.baseURL + "add-videos", vid);
  }

  putVideo(vid: Video){
   // return this.http.put(this.baseURL + "update/"+ vid._id, vid);
   var headers = new HttpHeaders();
   headers.append('Content-Type', 'application/json');
   return this.http.put(this.baseURL + vid._id, vid, {
     headers: {
       "Content-type" : "application/json"
     }
   }).pipe(
     catchError(this.errorHandler)
   );

  }

  deleteVideo(_id: String){
    return this.http.delete(this.baseURL + "delete/" + _id);
  }

  errorHandler(error: HttpErrorResponse){
    // return (error.message || "Server Error");
    return observableThrowError(error.message || "Server Error");
  }

}
