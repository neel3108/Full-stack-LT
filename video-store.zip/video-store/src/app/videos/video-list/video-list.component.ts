import { Component, OnInit } from "@angular/core";
import { Subscription } from 'rxjs';

import { VideoService } from '../videos.service';
import { Video } from '../video.model';


@Component({
  selector: 'app-video-list',
  templateUrl: './video-list.component.html',
  styleUrls: ['./video-list-component.css']
})
export class VideoListComponent implements OnInit{
  videos: Video[];

  constructor (public videoService: VideoService) {

  }

  ngOnInit(){
    this.showVideoList();
  }

  showVideoList(){
    this.videoService.getVideoList().subscribe(
      res =>{
        this.videoService.videos = res as Video[] ;

      }
    )
  }

  onDelete(_id: String){
    if (confirm('Do you want to delete this record?') == true){
    this.videoService.deleteVideo(_id).subscribe((res) => {
      alert('video deleted!');
      this.showVideoList();
    });

    }
  }



}
