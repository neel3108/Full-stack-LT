import { Component, OnInit } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';

import { Video } from '../video.model';
import { VideoService } from "../videos.service";



@Component({
  selector: 'update-video',
  templateUrl: './update-video.component.html'
})
export class UpdateVideoComponent{
  private updateVideoData: Video;
  private  _id: String;

 constructor(public videoService: VideoService, public router: Router,public _router: ActivatedRoute ){}

 onInit(){
   this.getVidData();

 }

 getVidData(){
   this._id = this._router.snapshot.paramMap.get('id');
   this.videoService.getSelectedVideo(this._id).subscribe((data) => {
     this.updateVideoData = data as Video;
     alert(data);
     })
 }

 onUpdate(form: NgForm, vid: Video){
    this.videoService.putVideo(this.updateVideoData).subscribe((res) => {
      alert('Video Updated');
      this.router.navigateByUrl('/videoList');
    })
 }

}
