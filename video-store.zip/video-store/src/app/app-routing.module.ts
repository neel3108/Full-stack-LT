import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddVideoComponent } from './videos/add-video/add-video.component';

import { VideoListComponent } from './videos/video-list/video-list.component';
import { UpdateVideoComponent } from '../app/videos/update-video/update-video.component';
import { CustomerVideoList } from '../app/videos/customers-video-list/customers-video-list.component';
import { AdminLoginComponent } from './videos/admin/admin-login/admin-login.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'admin-login',
    component: AdminLoginComponent
  },
  {
    path:'home',
    component: CustomerVideoList
  },
  {
    path:'add-video',
    component: AddVideoComponent,
  },
 {
     path:'update/:id',
     component: UpdateVideoComponent
  },
  {
    path: 'videoList',
    component: VideoListComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
