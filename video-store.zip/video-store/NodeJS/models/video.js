const mongoose = require('mongoose');

var Video = mongoose.model('Video', {
    vidTitle: String,
    runningTime: String,
    director: String,
    genre: String,
    rating: String,
    status: String
})

module.exports =  Video ;
