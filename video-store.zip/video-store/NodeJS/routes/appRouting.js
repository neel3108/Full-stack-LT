const express = require('express');
var router = express.Router();
var objectID = require('mongoose').Types.ObjectId;

var Video  = require('../models/video');

// localhost:4100/videos
router.get('/', (req, res) => {
    Video.find((err, docs) => {
        if (!err){
          res.send(docs);
        }
        else {
            console.log('Error in retriving videos: ' + JSON.stringify(err, undefined, 2));
        }
    })
});

router.get('/:id', (req, res) => {
    if (!objectID.isValid(req.params.id)){
        return res.status(400).send(`No record with given ID: ${req.param.id}`)
    }

Video.findById(req.params.id, (err,docs) => {
    if (!err){ res.send(docs); }
    else {
        console.log('Error in retriving video: ' + JSON.stringify(err, undefined, 2));
    }
})
});

router.post('/add-videos', (req, res) => {
    var vid = new Video({
        vidTitle: req.body.vidTitle,
        runningTime: req.body.runningTime,
        director: req.body.director,
        genre: req.body.genre,
        rating: req.body.rating,
        status: req.body.status
    })
    vid.save((err, doc) => {
        if (!err) { res.send(doc);
        console.log(doc) }
        else {
            console.log('Error in saving video: ' + JSON.stringify(err, undefined, 2));
        }
    })
})


router.put('/update/:id', (req, res) => {
    if (!objectID.isValid(req.params.id)){
        return res.status(400).send(`No record with given ID: ${req.param.id}`)
    }
    var newvid = {
        vidTitle: req.body.vidTitle,
        runningTime: req.body.runningTime,
        director: req.body.director,
        genre: req.body.genre,
        rating: req.body.rating,
        status: req.body.status
    };
    Video.findByIdAndUpdate(req.params.id, { $set: newvid}, { new: true}, (err, newvid) => {
        if (!err) { res.send(newvid); }
        else {
            console.log('Error in updating video: ' + JSON.stringify(err, undefined, 2));
        }
    })
});

router.delete('/delete/:id', (req, res) => {
    if (!objectID.isValid(req.params.id)){
        return res.status(400).send(`No record with given ID: ${req.params.id}`)
    }
    Video.findByIdAndDelete(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else {
            console.log('Error in deleting video: ' + JSON.stringify(err, undefined, 2));
        }
    })
})

module.exports = router;
