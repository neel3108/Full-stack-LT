const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const { mongoose } = require('./db.js');
var videoRouting = require('./routes/appRouting');

var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors({ origin: 'http://localhost:4200' }));

app.listen(4100, () => console.log('Server started @ 4100'));

app.use('/videos', videoRouting);

